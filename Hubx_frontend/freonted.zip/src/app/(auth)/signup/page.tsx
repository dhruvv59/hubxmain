
import React from "react";
import { SignupForm } from "@/components/auth/SignupForm";

export default function SignupPage() {
    return (
        <SignupForm />
    );
}
