import BookExcursionClient from "@/components/teacher/excursion/BookExcursionClient";

export default function Page() {
    return <BookExcursionClient />;
}
